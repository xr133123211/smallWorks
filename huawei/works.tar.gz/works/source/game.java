import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;




class Game {

	public int id;
	public static int blind  = 40;
	public static int call_need = 0;
	public static int pot_sum = 0;

	public static int myMoney = 4000;
	public static int myJetton=0;	
	public static int cardNum=0;
	public static int gameCount=0;
	public static int myBet = 0;
	
	public static CardInfo[] myCards = new CardInfo[7];
	
	public static String rec;

	private ClientNet client;
	public HashMap<Integer,PlayerInfo> allPlayers = new HashMap<Integer,PlayerInfo>();
	
	enum Action {
		blind, raise, check, fold, call, allIn, smallRaise, bigRaise;
	}
	
	public int getLevel(String a){
		String[] p = {"HIGH_CARD", "ONE_PAIR", "TWO_PAIR", "THREE_OF_A_KIND","STRAIGHT", "FLUSH", "FULL_HOUSE", "FOUR_OF_A_KIND", "STRAIGHT_FLUSH"};
		for(int i=0;i<9;i++){
			if (p[i].equals(a)) return i;			
		}
		return 0;
	}

	enum cardLevel {
		HIGH_CARD, ONE_PAIR, TWO_PAIR, THREE_OF_A_KIND, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH;
	}
	public Game(int id,InetAddress serverIP, int serverSocket,InetAddress clientIP, int clientSocket){
		this.id  = id;
		client = new ClientNet(this,serverIP,serverSocket,clientIP,clientSocket,id);
		client.start();
	}
	
	 
	public void restart(){
		cardNum = 0;
		myBet = 0;
		if(allPlayers.size()==0) client.readInfo("/seat");
	}

	public void updatePlayerInfo(int pid, int jetton, int money, int bet,String action) {
		if(pid == id) {
			myBet = bet;
			myMoney = money;
			myJetton = jetton;
			return;
		}
		if(bet>=myBet) call_need = bet-myBet; 
		PlayerInfo p = allPlayers.get(pid);
		p.update(jetton,money,bet);		
		if(action.equals("fold")){
			p.vaild=false;
		}
		else {
			p.vaild=true;
		}		
		p.addAction(action);
		
	}
	public void refreshPlayer(int pid){
		PlayerInfo p = allPlayers.get(pid);
		p.refresh();
	}
	
	
	class GameInfo {
			public int rank;
			public CardInfo cards[];
			public String nutHand;
			public ArrayList<String> actions;

			public GameInfo(int rank, CardInfo[] cards, String nutHand,ArrayList<String> actions) {
				this.rank = rank;
				this.cards = cards;
				this.nutHand = nutHand;
				this.actions = actions;
			}

		}

	class CardInfo {
		
		final String[] colors = { "SPADES", "HEARTS", "CLUBS", "DIAMONDS" };
		
		
		int color;
		int point;

		public CardInfo(String c, int p) {
			point = p;
			color = -1;
			for (int i = 0; i < 4; i++)
				if (colors[i].equals(c))
					color = i;
		}

		public CardInfo(int v) {
			point = v % 15  ;
			color = v / 15;
		}

		public String getColor() {
			return colors[color];
		}
		public int getColorInt(){
			return color;
		}

		public int getPoint() {
			return point;
		}

		public int getValue() {
			return point + 15 * (color);
		}
		public boolean sameColor(CardInfo card){
			return card.getValue()==this.getValue();
		}
		public boolean samePoint(CardInfo card){
			return card.getPoint()==color;
		}

	}
	
	class ClientNet extends Thread {

		Socket client;
		BufferedReader reader;
		PrintWriter writer;
		
		Game game;
		int id;

		public ClientNet(Game g,InetAddress serverIP, int serverSocket,InetAddress clientIP, int clientSocket,int id) {
			String sendMsg = "reg: " + id + " zane" + " need_notify";
			this.game = g;
			this.id = id;
			while (true) {
				try {
					client = new Socket(serverIP, serverSocket, clientIP,clientSocket);
					reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
					writer = new PrintWriter(client.getOutputStream());
					break;
				} catch (Exception e) {
				}
			}
			sendMessage(sendMsg);
		}

		public void sendMessage(String msg){
			while (true) {
				try {
					writer.println(msg);
					writer.flush();
					break;
				} catch (Exception e) {
				}
			}
		}
		

		private int getPoint(String s) {
			if (s.startsWith("J"))
				return 11;
			else if (s.startsWith("A"))
				return 14;
			else if (s.startsWith("Q"))
				return 12;
			else if (s.startsWith("K"))
				return 13;
			else
				return Integer.parseInt(s);

		}
		
		
		private String[] splitString(String text) {
			String b[];
			String a[] = text.split(":");
			if (a.length > 1) {
				String head = a[0];
				String tail = a[1];
				b = tail.split(" ");
				b[0] = head;
			} else
				b = text.split(" ");
			return b;
		}
		
		
		public void readInfo(String end){
			while (true) {
				try {
					String text = reader.readLine();
					if (text != null) {
						if (text.startsWith(end))
							break;
						else{
							if(end.startsWith("/inquire")) getPlayerInfo(text);
							else if(end.startsWith("/seat")) getSeatInfo(text);
							else if(end.startsWith("/notify")) getPlayerInfo(text);
							else if(end.startsWith("/showdown")) getshowDown(text);
							else if(end.startsWith("/pot-win")) getPot(text);
							else if(end.startsWith("/blind")) getBlind(text);
							else if(end.startsWith("/river")) getCard(text);
							else if(end.startsWith("/turn")) getCard(text);
							else if(end.startsWith("/flop")) getCard(text);
							else if(end.startsWith("/hold")) getCard(text);
							else if(end.startsWith("/common")) ;
							
							}
					}
				} catch (Exception e) {
				}
			}
		}


		private void getPot(String text){
			/*String[] c = splitString(text);
			int id = Integer.parseInt(c[0]);
			int number = Integer.parseInt(c[1]);*/
			
		}
		
		private void getBlind(String text) {
			//String[] c = splitString(text);
			//int pid = Integer.parseInt(c[0]);
			//int bet = Integer.parseInt(c[1]);
			//if (bet>blind) blind = bet;
		}

		private void getSeatInfo(String text){
			int j;
			String[] c = splitString(text);
			if (c.length>3) j =0;
			else j = -1; 
			int id = Integer.parseInt(c[1 + j]);
			//int jetton = Integer.parseInt(c[2 + j]);
			//int money = Integer.parseInt(c[3 + j]);
			game.allPlayers.put(id,new PlayerInfo(id));
			
		}
		
		private void getPlayerInfo(String text){
			String[] c = splitString(text);
			if (text.startsWith("total")) {
				Game.pot_sum = Integer.parseInt(c[1]);				
			} else {
				int pid = Integer.parseInt(c[0]);
				int jetton = Integer.parseInt(c[1]);
				int money = Integer.parseInt(c[2]);
				int bet = Integer.parseInt(c[3]);
				String action = c[4];
				game.updatePlayerInfo(pid,jetton,money,bet,action);
			}
		}
		private void getCard(String text)  {
			String[] c = text.split(" ");
			int p = getPoint(c[1]);
			Game.myCards[Game.cardNum] = new CardInfo(c[0], p);
			Game.cardNum++;
		}

		private void getshowDown(String text) {
			CardInfo[] pcards = new CardInfo[7];			
			String c[] = splitString(text);
			int rank = Integer.parseInt(c[0]);
			int pid = Integer.parseInt(c[1]);
			if (pid==id) return;
			String color1 = c[2];
			int point1 = getPoint(c[3]);
			String color2 = c[4];
			int point2 = getPoint(c[5]);
			String nutHand = c[6];
			for(int i=2;i<7;i++) pcards[i] = Game.myCards[i];
			pcards[0] = new CardInfo(color1,point1); 
			pcards[1] = new CardInfo(color2,point2);
			game.allPlayers.get(pid).addGameInfo(rank,pcards,nutHand);
			if(rank==1){
				int a = game.getLevel(nutHand);
				if (a<2) {
					AIHelper.foldHand -=0.04;
					AIHelper.raiseHand-=0.03;
					AIHelper.Hands1 -= 0.01;
					AIHelper.Hands2 -= 0.01;
				}else if(a>4){
					AIHelper.foldHand +=0.03;
					AIHelper.raiseHand+=0.02;										
					AIHelper.Hands1 += 0.01;
					AIHelper.Hands2 += 0.01;
				}
			}else if(rank>2){
				AIHelper.foldHand +=0.02;
				AIHelper.raiseHand+=0.01;										
				AIHelper.Hands1 += 0.01;
				AIHelper.Hands2 += 0.01;
			}
		}
		

		
		@Override
		public void run() {
			
			while(true){
				try {
					String text = reader.readLine();
					if (text != null){
						if (text.startsWith("inquire/")) {	
							readInfo("/inquire");
							Game.rec = "check";
							new AIThinking().start();
							Thread.sleep(400);
							sendMessage(Game.rec);
						}
						else if (text.startsWith("hold/")){
							readInfo("/hold");
						}
						else if (text.startsWith("flop/")){
							readInfo("/flop");
						}	
						else if (text.startsWith("turn/")){
							readInfo("/turn");
						}
						else if (text.startsWith("river/")){
							readInfo("/river");
						}
						else if (text.startsWith("blind/")){
							readInfo("/blind");
						}
						else if (text.startsWith("showdown/")){
							readInfo("/common");
							readInfo("/showdown");
						}
						else if (text.startsWith("pot-win/")){
							readInfo("/pot-win");
						}
						else if (text.startsWith("notify/")){
							readInfo("/notify");
						}
						else if (text.startsWith("seat/")){
							game.restart();								
						}
						else if (text.startsWith("game-over")) {
							reader.close();
							writer.close();
							client.close();
							break;
						} 
					}
				}catch(Exception e){					
				}					
			}
		}


		
	}
	class PlayerInfo {
		public int id;
		public int jetton;
		public int money;
		public boolean vaild ;
		Queue<GameInfo> gameInfos = new LinkedList<GameInfo>();
		ArrayList<String> actions = new  ArrayList<String>();
		
		public PlayerInfo(int id){
			this.id = id;
		}
		public int update(int jetton, int money, int bet) {
			int change = this.jetton-jetton;
			this.jetton = jetton;
			this.money = money;
			return change;
		}
		public void addGameInfo(int rank, CardInfo[] cards, String nutHand) {
	
			gameInfos.add(new GameInfo(rank,cards,nutHand,actions));
			actions = new ArrayList<String>();
			
		}
		public void addAction(String action){
			actions.add(action);
		}
		public void refresh(){
			actions  = new  ArrayList<String>();
		}
	}

	
	static class AIHelper {

	static double foldHand = 0.41;
	static double raiseHand = 1.0;
	static double maxRaiseRate = 5;
	static double raiseHandMux = 10;
	static double Hands1 = 1.0;
	static double Hands2 = 1.1;
			

	
	static double[] potWin = {0,0.1,0.2,0.5,0.55,0.7,0.75,0.9,0.95};	
	static double twoLevel[][] = 
		{{112,109,90,90,80,50,50,50,50,50,40,40,40},//A
		{90,109,90,80,70,50,40,40,40,40,30,30,30},//K
		{80,70,106,80,70,60,40,0,0,0,0,0,0},//Q
		{70,60,60,103,80,70,50,30,0,0,0,0,0},//J
		{50,50,50,60,90,70,60,40,0,0,0,0,0},//T
		{30,30,30,40,40,80,70,60,30,0,0,0,0},//9
		{20,10,0,0,30,40,70,60,50,30,0,0,0},//8
		{20,10,0,0,0,0,30,60,60,50,30,0,0},//7
		{20,10,0,0,0,0,0,30,50,60,40,0,0},//6
		{20,10,0,0,0,0,0,0,30,50,50,40,0},//5
		{20,10,0,0,0,0,0,0,0,30,40,40,30},//4
		{20,10,0,0,0,0,0,0,0,0,30,40,30},//3
		{20,10,0,0,0,0,0,0,0,0,0,0,40}};//2
	
	public static double adjustHandCards(CardInfo[] hands){
		
		int max = hands[0].point;
		int min = hands[1].point;
		int swap;		
		if (max<min){ swap = max; max = min; min = swap;}
		if(hands[0].sameColor(hands[1])) return twoLevel[14-max][14-min]/100;
		else return twoLevel[14-min][14-max]/100;
		
	}
	

	public static String adjustByHandCards(CardInfo[] hands) {
		double chooseMethod;// <0.6 fold >1 raise else cheek
		double handLevel = adjustHandCards(hands);// biger is good
		if(Game.call_need==0) Game.call_need = 1;
		double pot = Game.pot_sum / Game.call_need;// biger is good
		if (handLevel < foldHand)
			return "fold";
		else if (handLevel > raiseHand) {
			if (handLevel * pot > raiseHandMux)
				return raise();
			else if (Math.random() > 0.5)
				return "call";
			else
				return "raise " + Game.blind;
		} else {
			chooseMethod = Math.random() * 10 * handLevel * pot;
			if (chooseMethod > 50)
				return "raise" + Game.blind;
			else if (chooseMethod > 30)
				return "call";
			else
				return "fold";
		}

	}

	public static String raise() {
		return "raise " + getRaise();
	}

	public static int getRaise() {
		return (int) (Math.random() * maxRaiseRate);
	}

	public static String adjustByCards(CardInfo[] cards, int cardCount) {

		double[] pPot1 = new double[9];
		double[] pPot2 = new double[9];
		int point[] = new int[15];
		int color[] = new int[4];
		int left = 7-cardCount;
		for (int i = 2; i < cardCount; i++) {
			point[cards[i].point]++;
			color[cards[i].color]++;
		}
		pPot1 = getPofSame(point,2);
		pPot1[4] = getPofStraight(point,2);
		pPot1[6] = getPofFlush(color,2);
		pPot1[8] = getPofStraightFlush(cards,cardCount,2);

		for (int i = 0; i < 2; i++) {
			point[cards[i].point]++;
			color[cards[i].color]++;
		}
		pPot2 = getPofSame(point,left);
		pPot2[4] = getPofStraight(point,left);
		pPot2[6] = getPofFlush(color,left);
		pPot2[8] = getPofStraightFlush(cards,cardCount,left);
		
		
		double pot = Game.pot_sum / (Game.call_need+1);// biger is good
		double adjust1=getPoint(pPot1)*pot;
		double adjust2=getPoint(pPot2)*pot;
		double minus = adjust2-adjust1;
		if(minus>Hands2) return raise();
		else if(adjust2>Hands1) return "call";
		else if(Game.call_need==0) return "check " ;
		else return "fold ";		

	}

	public static double getPoint(double[] a){
		double adjust = 0;
		boolean end = false;
		for(int i=8;i>=0;i--){		
			if(a[i]>=1) {a[i]=1;end=true;}
			adjust = potWin[i]*a[i]+adjust;
			if(end) break;
		}
		return adjust;
	}
	
	static double  getPofStraightFlush(CardInfo[] cards, int cardCount,int rest)
	{
		double ans=0;
		boolean hash[][]=new boolean[4][15];
		for (int i=0;i<4;i++)
			for (int j=2;j<15;j++)
		{
			hash[i][j]=false;
		}
		for (int i=0;i<cardCount;i++)
		{
			hash[cards[i].color][cards[i].point]=true;
			if (cards[i].point==14) hash[cards[i].color][1]=true;
		}
		for (int i=0;i<4;i++)
			for (int j=1;j<11;j++)
				
			{
				int c=0;
				for (int k=0;k<5;k++)
				if (hash[i][j+k]==false) c++;
				if (c>rest) break;
				else 
				{
					if (c==0) return 1;
					if (c==1&&rest==1) ans+=1/(52-cardCount);
					if (c==1&&rest==2) ans+=2/(52-cardCount);
					if (c==2&&rest==2) ans+=2/((52-cardCount)*(51-cardCount));				
				}
			}		
		return ans;
	}
	

	public static double[] getPofSame(int a[], int leftCard){

		double[] b = new double[9];		
		int three = 0;
		int pairs = 0;
		for (int i = 2; i < 15; i++) {
			if (a[i] == 4)
				b[7]=1;
			else if (a[i] == 3)
				three=i;
			else if (a[i] == 2)
				pairs++;

		}				
		if (three > 0)
			{
			
			b[7]+=1/1035;
			if (pairs > 0) b[6]=1;
			else {
				if(leftCard == 1)b[5]+=1/15;
				else b[5]+=1/345;
			}
			b[3]=1;	
			}							
		else if (pairs > 1)
			{
			if(leftCard==1) b[5]+=1/23;
			else b[5]+=1/506;
			b[2]=1;
			}
		else if (pairs > 0)
			{
			if(leftCard==1) b[3]+=1/46;
			else b[3]+=1/1035;
			b[1]=1;
			}
		else
			{
			
			if(leftCard==1) b[1]+=1/46;
			else b[1]+=1/1035;
			b[0]=1;
			}
		return b;
	}
	
	
	public static double getPofStraight(int a[], int leftCount) {
		a[1] = a[14];
		int total = 0;
		for (int i = 1; i < 11; i++) {
			int need = 0;
			for (int j = 0; j < 5; j++) {
				if (a[i + j] == 0)
					need++;
			}
			if (need == 0)
				return 1;
			else if (need <= leftCount)
				if(need==1) total+=1/46*leftCount;
				else total+= 1/1035;
				
		}
				
		return total;

	}
	
	
	public static double getPofFlush(int[] colors,int rest)
	{
		double ans=0;
	
		for (int i=0;i<4;i++)
		{
			int c=colors[i];
			c = 5-c;
			if (c>rest) break;
			else 
			{
				if (c==0) return 1;
				if (c==1&&rest==1) ans+=9/(46);
				if (c==1&&rest==2) ans+=18/(46);
				if (c==2&&rest==2) ans+=72/(46*45);
 			}
			
		}	
		return ans;
		
	}
	}

	class AIThinking extends Thread{
		@Override
		public void run(){
			String result ;
			if(Game.cardNum==2) result = AIHelper.adjustByHandCards(Game.myCards);
			else result = AIHelper.adjustByCards(Game.myCards,Game.cardNum);
			Game.rec = result;
		} 
		
	}

	
	public static void main(String args[]) throws Exception{
		int id = Integer.parseInt(args[4]);		
		Game game = new Game(id,InetAddress.getByName(args[0]),Integer.parseInt(args[1]),InetAddress.getByName(args[2]),Integer.parseInt(args[3]));
		//ClientNet client = new ClientNet(game,InetAddress.getByName(args[0]),Integer.parseInt(args[1]),InetAddress.getByName(args[2]),Integer.parseInt(args[3]),id);		
		//game.startWith(client);
	}

}